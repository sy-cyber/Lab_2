import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

import pyodbc

from interface.main import MainInterface
from services.database import Database
from services.orders_manager import OrdersManager
from services.products_in_order_manager import ProductsInOrderManager


class Init:

    def __init__(self):
        self._buy_products_list = {}
        self._product_list = {}
        self._root = None
        self._main_productlist_frame = None
        self._main_orderinfo_userinfo_frame = None

        self.db = Database.getInstance('localhost', 'test')


    def run(self):
        self.init()

        main_interface = MainInterface(self._root)

        main_interface.run()

        self._root.mainloop()


    def init(self):
        self._root = tk.Tk()
        self._root.title("Оформлення замовлення")
        self._root.geometry("800x400")






