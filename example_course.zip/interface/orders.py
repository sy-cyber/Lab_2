import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from services.database import Database
from services.orders_manager import OrdersManager
from services.products_in_order_manager import ProductsInOrderManager


class OrdersInterface:

    def __init__(self, root):
        self._product_list = {}
        self._products_list_in_order = {}
        self._root = root

        self.db = Database.getInstance('localhost', 'test')

    # Друге вікно
    def open_orders_window(self):
        self._orders_window = tk.Toplevel(self._root)  # Створення дочірнього вікна
        self._orders_window.title("Додаткове вікно")
        self._orders_window.geometry("1000x400")

        self.orders_window_orderslist()
        self.orders_window_productsinfo()
        self.orders_window_orderinfo()

        self.get_orders()
        self.update_orders_list_box()

        self.get_product()
        self.update_products_list_box()

    def orders_window_orderslist(self):

        self._orders_window_orderslist = tk.Frame(self._orders_window)
        self._orders_window_orderslist.pack(padx=10, pady=10, side=tk.LEFT, fill=tk.Y)

        # Поле пошуку продуктів
        search_label = tk.Label(self._orders_window_orderslist, text="Пошук замовлень:")
        search_label.grid(row=0, column=0, sticky=tk.W)

        self.search_orders_entry = ttk.Entry(self._orders_window_orderslist)
        self.search_orders_entry.grid(row=1, column=0, pady=(0, 10), sticky=tk.W + tk.E)

        btn_search = ttk.Button(self._orders_window_orderslist, text="Пошук", command=self.search_orders)
        btn_search.grid(row=1, column=1, padx=5, pady=(0, 10))

        self.listbox_orders = tk.Listbox(self._orders_window_orderslist, height=15)
        self.listbox_orders.grid(row=2, column=0, columnspan=2, padx=5, pady=(0, 10), sticky=tk.W + tk.E)

    def orders_window_productsinfo(self):

        self._orders_window_productsinfo = tk.Frame(self._orders_window)
        self._orders_window_productsinfo.pack(padx=10, pady=10, side=tk.LEFT, fill=tk.Y)

        # Поле пошуку продуктів
        search_label_product_in_orderform = tk.Label(self._orders_window_productsinfo, text="Пошук продуктів:")
        search_label_product_in_orderform.grid(row=0, column=0, sticky=tk.W)

        self.search_entry_product_in_orderform = ttk.Entry(self._orders_window_productsinfo)
        self.search_entry_product_in_orderform.grid(row=1, column=0, pady=(0, 10), sticky=tk.W + tk.E)

        btn_search_product_in_orderform = ttk.Button(self._orders_window_productsinfo, text="Пошук",
                                                     command=self.search_products)
        btn_search_product_in_orderform.grid(row=1, column=1, padx=5, pady=(0, 10))

        self.listbox_orders_product_in_orderform = tk.Listbox(self._orders_window_productsinfo, height=15)
        self.listbox_orders_product_in_orderform.grid(row=2, column=0, columnspan=2, padx=5, pady=(0, 10),
                                                      sticky=tk.W + tk.E)

        search_label = tk.Label(self._orders_window_productsinfo,
                                text="Додати продукт до замовлення \n(введіть кількість): ")
        search_label.grid(row=3, column=0, sticky=tk.W)

        self.count_entry = ttk.Entry(self._orders_window_productsinfo)
        self.count_entry.grid(row=4, column=0, pady=(0, 10), sticky=tk.W + tk.E)

        btn_search = ttk.Button(self._orders_window_productsinfo, text="Додати", command=self.add_product)
        btn_search.grid(row=4, column=1, padx=5, pady=(0, 10))

        self.listbox_orders.bind("<<ListboxSelect>>", self.select_order)

    def orders_window_orderinfo(self):

        self._orders_window_orderinfo = tk.Frame(self._orders_window)
        self._orders_window_orderinfo.pack(padx=10, pady=10, side=tk.LEFT, fill=tk.Y)

        label_id = tk.Label(self._orders_window_orderinfo, text="ID замовника:")
        label_id.grid(row=0, column=0, sticky=tk.W)
        self._label_user_id_value = tk.Label(self._orders_window_orderinfo, text="")
        self._label_user_id_value.grid(row=0, column=1, sticky=tk.W)

        label_order_id = tk.Label(self._orders_window_orderinfo, text="ID замовлення:")
        label_order_id.grid(row=1, column=0, sticky=tk.W)
        self._label_order_id_value = tk.Label(self._orders_window_orderinfo, text="")
        self._label_order_id_value.grid(row=1, column=1, sticky=tk.W)

        self._main_orderinfo_userinfo_frame_listbox_buy_products = tk.Listbox(self._orders_window_orderinfo,
                                                                              height=15, width=30)
        self._main_orderinfo_userinfo_frame_listbox_buy_products.grid(row=2, column=0, rowspan=4, columnspan=2,
                                                                      padx=5, pady=(0, 10),
                                                                      sticky=tk.W + tk.E)

        btn_search_product_in_orderform = ttk.Button(self._orders_window_orderinfo, text="Видалити продукт",
                                                     command=self.remove_product)

        btn_search_product_in_orderform.grid(row=7, column=0, padx=5, pady=(0, 10), stick='EW')

        self._orders_window_orderinfo_userinfo = tk.Frame(self._orders_window_orderinfo)
        self._orders_window_orderinfo_userinfo.grid(row=2, column=2, padx=10, sticky=tk.N)

        label_name = tk.Label(self._orders_window_orderinfo_userinfo, text="ПІБ:")
        label_name.grid(row=0, column=0, sticky=tk.W)
        self.entry_name_order = ttk.Entry(self._orders_window_orderinfo_userinfo, width=40)
        self.entry_name_order.grid(row=1, column=0, pady=(0, 10))

        label_phone = tk.Label(self._orders_window_orderinfo_userinfo, text="Телефон:")
        label_phone.grid(row=2, column=0, sticky=tk.W)
        self.entry_phone_order = ttk.Entry(self._orders_window_orderinfo_userinfo, width=40)
        self.entry_phone_order.grid(row=3, column=0, pady=(0, 10))

        label_address = tk.Label(self._orders_window_orderinfo_userinfo, text="Адреса:")
        label_address.grid(row=4, column=0, sticky=tk.W)
        self.entry_address_order = ttk.Entry(self._orders_window_orderinfo_userinfo, width=40)
        self.entry_address_order.grid(row=5, column=0, pady=(0, 10))

        # Кнопка оформлення замовлення на єкрані всіх замовлень
        btn_submit = ttk.Button(self._orders_window_orderinfo_userinfo, text="Оновити замовлення",
                                command=self.update_order)
        btn_submit.grid(row=6, column=0, pady=10)

    # Методи, які отримують інформацію для інтерфейсу

    def get_orders(self):

        orders = self.db.get_orders()
        self._orders_list = {}

        for item in orders:
            self._orders_list[f'#{item[0]} {item[4]} {item[3]}'] = item

    def get_product(self):

        products = self.db.get_products()

        self._product_list = {}

        for item in products:
            self._product_list[f'#{item[0]} - {item[1]}'] = item

    def add_product(self):
        product_id = False

        selected_index = self.listbox_orders_product_in_orderform.curselection()  # Повертає індекс вибраного елемента
        if selected_index:  # Перевіряємо, чи щось вибрано
            selected_item = self.listbox_orders_product_in_orderform.get(selected_index)

            product = selected_item.split(" ")
            product_id = product[0]
            product_id = int(product_id[1:])

        amount = self.count_entry.get()

        if amount == '':
            messagebox.showerror("Помилка", "Виберіть продукт та введіть кількість")

        if product_id and int(amount) > 0:
            self._products_in_order[f"{selected_item} - {amount}"] = {
                'product_id': product_id,
                'amount': amount,
                'price': 100
            }

            self._main_orderinfo_userinfo_frame_listbox_buy_products.insert(tk.END, f"{selected_item} - {amount}")

            self.count_entry.delete(0, tk.END)

    def remove_product(self):
        selected_items = self._main_orderinfo_userinfo_frame_listbox_buy_products.curselection()
        selected_name = self._main_orderinfo_userinfo_frame_listbox_buy_products.get(selected_items)

        del self._products_in_order[selected_name]

        self._main_orderinfo_userinfo_frame_listbox_buy_products.delete(selected_items)

    def select_order(self, event):
        selected_index = self.listbox_orders.curselection()  # Повертає індекс вибраного елемента
        if selected_index:  # Перевіряємо, чи щось вибрано
            selected_item = self.listbox_orders.get(selected_index)

            order = self._orders_list[selected_item]

            self.load_order_on_form(order)

            self._label_user_id_value.config(text=str(order[1]))
            self._label_order_id_value.config(text=str(order[0]))

            print(order)
            products_in_order_manager = ProductsInOrderManager(order[0])

            self._products_in_order = {}

            products = products_in_order_manager.get_products_in_order()
            print(products)
            for item in products:
                self._products_in_order[f'#{item[0]} {item[3]}'] = item

            self.update_products_in_order_user_list_box(self._products_in_order)

    def load_order_on_form(self, order):
        self.entry_name_order.delete(0, tk.END)  # Очищення поля перед вставкою
        self.entry_name_order.insert(0, order[4])

        self.entry_phone_order.delete(0, tk.END)  # Очищення поля перед вставкою
        self.entry_phone_order.insert(0, order[3])

        self.entry_address_order.delete(0, tk.END)  # Очищення поля перед вставкою
        self.entry_address_order.insert(0, order[5])

    def update_products_in_order_list_box(self, products):
        self._main_orderinfo_userinfo_frame_listbox_buy_products.delete(0, tk.END)

        for product in products.keys():
            self._main_orderinfo_userinfo_frame_listbox_buy_products.insert(tk.END, product)

    def update_orders_list_box(self, orders=None):
        self.listbox_orders.delete(0, tk.END)

        if orders is None:
            orders = self._orders_list

        for order in orders.keys():
            self.listbox_orders.insert(tk.END, order)

    def update_products_in_order_user_list_box(self, products):
        self._main_orderinfo_userinfo_frame_listbox_buy_products.delete(0, tk.END)
        for product in products.keys():
            self._main_orderinfo_userinfo_frame_listbox_buy_products.insert(tk.END, product)

    def search_products(self):
        search_term = self.search_entry_product_in_orderform.get().lower()

        filtered = {}
        for product in self._product_list.keys():
            if search_term in product.lower():
                filtered[product] = self._product_list[product]

        self.update_products_list_box(filtered)

    def search_orders(self):
        search_term = self.search_orders_entry.get().lower()

        filtered = {}
        for order in self._orders_list.keys():
            if search_term in order.lower():
                filtered[order] = self._orders_list[order]

        self.update_orders_list_box(filtered)

    def update_products_list_box(self, product=None):
        self.listbox_orders_product_in_orderform.delete(0, tk.END)

        if product is None:
            product = self._product_list

        for product in product.keys():
            self.listbox_orders_product_in_orderform.insert(tk.END, product)

    def update_order(self):

        selected_products = self._main_orderinfo_userinfo_frame_listbox_buy_products.get(0, tk.END)

        full_name = self.entry_name_order.get()
        phone = self.entry_phone_order.get()
        address = self.entry_address_order.get()

        if not (selected_products and full_name and phone and address):
            messagebox.showerror("Помилка", "Заповніть усі поля та виберіть продукт")
            return

        products = []
        for item in selected_products:
            products.append(self._products_in_order[item])

        customer_id = int(self._label_user_id_value.cget("text"))
        order_id = int(self._label_order_id_value.cget("text"))

        order_manager = OrdersManager(products, full_name, phone, address, order_id, customer_id)
        order_manager.update_order()

        messagebox.showinfo("Замовлення оформлено",
                            f"Продукт: {selected_products[0]} ...\nПІБ: {full_name}\nТелефон: {phone}\nАдреса: {address}")
