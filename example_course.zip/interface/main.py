import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from interface.orders import OrdersInterface
from services.database import Database
from services.orders_manager import OrdersManager


class MainInterface:

    def __init__(self, root):
        self._product_list = {}
        self._buy_products_list = {}
        self._root = root

        self.db = Database.getInstance('localhost', 'test')

        self._orders_interface = OrdersInterface(self._root)

    def run(self):
        self.main_product_list_frame()
        self.main_orderinfo_frame()

        self.get_product()
        # Заповнюємо Listbox продуктами
        self.update_products_list_box()

        self.main_orderinfo_userinfo_frame()

    # Головний екран

    def main_product_list_frame(self):
        self._main_productlist_frame = tk.Frame(self._root)
        self._main_productlist_frame.pack(padx=10, pady=10, side=tk.LEFT, fill=tk.Y)

        # Поле пошуку продуктів
        search_label = tk.Label(self._main_productlist_frame, text="Пошук продуктів:")
        search_label.grid(row=0, column=0, sticky=tk.W)

        self.search_entry = ttk.Entry(self._main_productlist_frame)
        self.search_entry.grid(row=1, column=0, pady=(0, 10), sticky=tk.W + tk.E)

        btn_search = ttk.Button(self._main_productlist_frame, text="Пошук", command=self.search_products)
        btn_search.grid(row=1, column=1, padx=5, pady=(0, 10))

        # Список продуктів (Listbox)
        self.listbox_products = tk.Listbox(self._main_productlist_frame, height=15)
        self.listbox_products.grid(row=2, column=0, columnspan=2, padx=5, pady=(0, 10), sticky=tk.W + tk.E)

        search_label = tk.Label(self._main_productlist_frame, text="Додати продукт до замовлення \n(введіть кількість): ")
        search_label.grid(row=3, column=0, sticky=tk.W)

        self.count_entry = ttk.Entry(self._main_productlist_frame)
        self.count_entry.grid(row=4, column=0, pady=(0, 10), sticky=tk.W + tk.E)

        btn_search = ttk.Button(self._main_productlist_frame, text="Додати", command=self.add_product)
        btn_search.grid(row=4, column=1, padx=5, pady=(0, 10))


        btn_search = ttk.Button(self._root, text="Перейти до всіх замовлень", command=self._orders_interface.open_orders_window)
        btn_search.pack(padx=5, pady=(0, 10), side=tk.BOTTOM, fill=tk.Y)


    def main_orderinfo_frame(self):

        self._main_orderinfo_frame = tk.Frame(self._root)
        self._main_orderinfo_frame.pack(padx=10, pady=10, side=tk.RIGHT, fill=tk.Y)


        self.listbox_buy_products = tk.Listbox(self._main_orderinfo_frame, height=15, width=30)
        self.listbox_buy_products.grid(row=0, column=0, rowspan=4, padx=5, pady=(0, 10),
                                                      sticky=tk.W + tk.E)

        btn_search_product_in_orderform = ttk.Button(self._main_orderinfo_frame, text="Видалити продукт",
                                                     command=self.remove_product)

        btn_search_product_in_orderform.grid(row=5, column=0, padx=5, pady=(0, 10), stick='EW')

    def main_orderinfo_userinfo_frame(self):
        self._main_orderinfo_userinfo_frame = tk.Frame(self._main_orderinfo_frame)
        self._main_orderinfo_userinfo_frame.grid(row=2, column=2, padx=10, sticky=tk.N)


        label_name = tk.Label(self._main_orderinfo_userinfo_frame, text="ПІБ:")
        label_name.grid(row=0, column=0, sticky=tk.W)
        self.entry_name = ttk.Entry(self._main_orderinfo_userinfo_frame, width=40)
        self.entry_name.grid(row=1, column=0, pady=(0, 10))

        label_phone = tk.Label(self._main_orderinfo_userinfo_frame, text="Телефон:")
        label_phone.grid(row=2, column=0, sticky=tk.W)
        self.entry_phone = ttk.Entry(self._main_orderinfo_userinfo_frame, width=40)
        self.entry_phone.grid(row=3, column=0, pady=(0, 10))

        label_address = tk.Label(self._main_orderinfo_userinfo_frame, text="Адреса:")
        label_address.grid(row=4, column=0, sticky=tk.W)
        self.entry_address = ttk.Entry(self._main_orderinfo_userinfo_frame, width=40)
        self.entry_address.grid(row=5, column=0, pady=(0, 10))

        # Кнопка оформлення замовлення
        btn_submit = ttk.Button(self._main_orderinfo_userinfo_frame, text="Оформити замовлення", command=self.submit_order)
        btn_submit.grid(row=6, column=0, pady=10)

    #Методи, які отримують інформацію для інтерфейсу
    def get_product(self):

        products = self.db.get_products()

        self._product_list = {}

        for item in products:
            self._product_list[f'#{item[0]} {item[1]}'] = item


    # Методи для роботи з інтерфейсом

    def add_product(self):

        product_id = False

        selected_index = self.listbox_products.curselection()  # Повертає індекс вибраного елемента
        if selected_index:  # Перевіряємо, чи щось вибрано
            selected_item = self.listbox_products.get(selected_index)

            product = selected_item.split(" ")
            product_id = product[0]
            product_id = int(product_id[1:])

        amount = self.count_entry.get()

        if amount == '':
            messagebox.showerror("Помилка", "Виберіть продукт та введіть кількість")

        if product_id and int(amount) > 0:
            self._buy_products_list[f"{selected_item} - {amount}"] = {
                'product_id': product_id,
                'amount': amount,
                'price': 100
            }

            self.listbox_buy_products.insert(tk.END, f"{selected_item} - {amount}")

            self.count_entry.delete(0, tk.END)

    def remove_product(self):
        selected_items = self.listbox_buy_products.curselection()
        self.listbox_buy_products.delete(selected_items)


    def search_products(self):
        search_term = self.search_entry.get().lower()

        filtered = {}
        for product in self._product_list.keys():
            if search_term in product.lower():
                filtered[product] = self._product_list[product]

        self.update_products_list_box(filtered)


    def update_products_list_box(self, products = None):
        self.listbox_products.delete(0, tk.END)

        if products is None:
            products = self._product_list

        for product in products.keys():
            self.listbox_products.insert(tk.END, product)


    def submit_order(self):

        selected_products = self.listbox_buy_products.get(0, tk.END)

        full_name = self.entry_name.get()
        phone = self.entry_phone.get()
        address = self.entry_address.get()

        if not (selected_products and full_name and phone and address):
            messagebox.showerror("Помилка", "Заповніть усі поля та виберіть продукт")
            return

        products = []
        for item in selected_products:
            products.append(self._buy_products_list[item])

        # Тут можна додати логіку додавання до бази даних
        order_manager = OrdersManager(products, full_name, phone, address)
        order_manager.create_order()

        messagebox.showinfo("Замовлення оформлено",
                            f"Продукт: {selected_products[0]} ...\nПІБ: {full_name}\nТелефон: {phone}\nАдреса: {address}")


