from interface.init import Init

main = Init()

main.run()

