from services.database import Database


class ProductsInOrderManager:

    def __init__(self, order_id):

        self.order_id = order_id
        self._products = []

        self.database = Database.getInstance('localhost', 'test')
        self.get_products_in_order()

    def get_products_in_order(self):
        self._products = self.database.get_products_in_order(self.order_id)

        return self._products
