import pyodbc


class Database:

    instance = None

    @classmethod
    def getInstance(slc, server, database):
        if Database.instance is None:
            Database.instance = Database(server, database)

        return Database.instance

    def __init__(self, server, database):
        self.server = server
        self.database = database

        self.connections()

    #Приклад підключення до бази даних
    def connections(self):
        self.__connection = pyodbc.connect(
            f'DRIVER={{SQL Server}};SERVER={self.server};DATABASE={self.database};Trusted_Connection=yes;'
        )
        self._cursor = self.__connection.cursor()
        print("Connection")

    def close(self):
        self._cursor.close()
        self.__connection.close()

    # Приклади різних запитів

    #Приклади запитів на отримання даних
    def get_products(self):
        self._cursor.execute("SELECT * FROM products")

        return self._cursor.fetchall()

    def get_products_in_order(self, order_id):
        self._cursor.execute(
            "SELECT order_products.id, order_id, product_id, products.name, order_products.amount, order_products.price FROM order_products INNER JOIN products ON order_products.product_id = products.id WHERE order_id = ?",
            (order_id))

        return self._cursor.fetchall()

    def get_orders(self):
        self._cursor.execute(
            "SELECT orders.id, customer_id, status, full_name, phone, address FROM orders LEFT JOIN customers ON orders.customer_id = customers.id ORDER BY orders.id DESC")

        return self._cursor.fetchall()

    def get_customer_by_phone(self, phone):
        self._cursor.execute("SELECT * FROM customers WHERE phone = ?", (phone))

        return self._cursor.fetchone()

    #Приклади на вставку даних в таблицю
    def insert_order(self, customer_id):
        self._cursor.execute(
            "INSERT INTO orders (customer_id, status) OUTPUT INSERTED.id VALUES (?, 0)",
            (customer_id)
        )

        inserted_id = self._cursor.fetchone()[0]
        self.__connection.commit()

        return inserted_id

    def insert_products_in_order(self, products):
        self._cursor.executemany(
            "INSERT INTO order_products (order_id, product_id, amount, price) OUTPUT INSERTED.id VALUES (?, ?, ?, ?)",
            products
        )

        self.__connection.commit()

    def create_customer(self, full_name, phone, address):
        self._cursor.execute(
            "INSERT INTO customers (full_name, phone, address) OUTPUT INSERTED.id VALUES (?, ?, ?)",
            (full_name, phone, address)
        )
        inserted_id = self._cursor.fetchone()[0]
        self.__connection.commit()
        return inserted_id

    #Приклад на оновлення даних в таблиці
    def update_customer(self, customer_id, full_name, phone, address):
        self._cursor.execute(
            "UPDATE customers SET full_name = ?, phone = ?, address = ? WHERE id = ?",
            (full_name, phone, address, customer_id)
        )

        self.__connection.commit()

    #Приклад видалення записів з таблиці
    def delete_products_in_order(self, order_id):
        self._cursor.execute(
            "DELETE FROM order_products WHERE order_id = ?",
            (order_id)
        )

        self.__connection.commit()
