from services.database import Database

class OrdersManager:

    def __init__(self, products, full_name, phone, address, order_id = None, customer_id = None):
        self.__products = products
        self.__full_name = full_name
        self.__phone = phone
        self.__address = address
        self.__customer_id = customer_id
        self.__order_id = order_id

        self.db = Database.getInstance('localhost', 'test')

    def create_order(self):
        customer_id = self.get_customer_id()
        self.__customer_id = customer_id
        self.__save_order()

    def get_customer_id(self):
        customer = self.db.get_customer_by_phone(self.__phone)

        if not customer:
            customer_id = self.db.create_customer(self.__full_name, self.__phone, self.__address)
        else:
            customer_id = customer[0]

        return customer_id

    def update_customer(self):
        self.db.update_customer(self.__customer_id, self.__full_name, self.__phone, self.__address)

    def __save_order(self):


        order_id = self.db.insert_order(self.__customer_id)

        products = []

        for item in self.__products:
            product_that_is_added_to_the_database = (order_id, item['product_id'], item['amount'], item['price'])

            products.append(product_that_is_added_to_the_database)

        self.db.insert_products_in_order(products)


    def __update_order(self):

        products = []

        for item in self.__products:
            product_that_is_added_to_the_database = (self.__order_id, item[2], item[4], item[5])

            products.append(product_that_is_added_to_the_database)

        self.db.delete_products_in_order(self.__order_id)
        self.db.insert_products_in_order(products)

    def update_order(self):
        self.update_customer()

        self.__update_order()
